import {
  Component,
  ElementRef,
  ViewChild,
  inject,
  signal
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';


interface ChatMessage {
  id: string;
  sender: 'customer' | 'assistant';
  message: string;
  createdAt: Date;
}


interface ChatRequest {
  message: string;
  conversation_id: string;
  business_id: string;
}


interface ChatResponse {
  reply: string;
  conversation_id: string;
  intent?: string;
  booking_ready?: boolean;
  appointment_created?: boolean;
  appointment_id?: string | null;
}


@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink
  ],
  templateUrl: './chat.html',
  styleUrl: './chat.css'
})
export class ChatComponent {
  private readonly http = inject(HttpClient);

  @ViewChild('messagesContainer')
  messagesContainer?: ElementRef<HTMLDivElement>;

  private readonly apiUrl =
    'http://127.0.0.1:8000/api/chat';

  // Must exactly match the Firestore business document ID.
  businessId = 'demo_business_001';

  conversationId = signal('');

  messages = signal<ChatMessage[]>([]);

  messageInput = '';
  isSending = signal(false);
  errorMessage = signal('');
  appointmentId = signal<string | null>(null);

  suggestedMessages = [
    'What is your business name?',
    'What services do you offer?',
    'What are your opening hours?',
    'I want to book an appointment'
  ];

  constructor() {
    this.loadWelcomeMessage();
  }

  private loadWelcomeMessage(): void {
    this.isSending.set(true);

    const requestBody: ChatRequest = {
      message: 'Greet the customer using the saved welcome message and business name.',
      conversation_id: '',
      business_id: this.businessId
    };

    this.http
      .post<ChatResponse>(
        this.apiUrl,
        requestBody
      )
      .subscribe({
        next: response => {
          if (response.conversation_id) {
            this.conversationId.set(
              response.conversation_id
            );
          }

          this.messages.set([
            {
              id: crypto.randomUUID(),
              sender: 'assistant',
              message:
                response.reply ||
                'Hello! How can I help you today?',
              createdAt: new Date()
            }
          ]);

          this.isSending.set(false);
          this.scrollToBottom();
        },

        error: error => {
          console.error(
            'Welcome message request error:',
            error
          );

          this.messages.set([
            {
              id: crypto.randomUUID(),
              sender: 'assistant',
              message:
                'Hello! How can I help you today?',
              createdAt: new Date()
            }
          ]);

          this.isSending.set(false);
          this.scrollToBottom();
        }
      });
  }

  sendMessage(): void {
    const message = this.messageInput.trim();

    if (!message || this.isSending()) {
      return;
    }

    this.addMessage(
      'customer',
      message
    );

    this.messageInput = '';
    this.errorMessage.set('');
    this.isSending.set(true);

    const requestBody: ChatRequest = {
      message,
      conversation_id:
        this.conversationId(),
      business_id:
        this.businessId
    };

    console.log(
      'Chat request:',
      requestBody
    );

    this.http
      .post<ChatResponse>(
        this.apiUrl,
        requestBody
      )
      .subscribe({
        next: response => {
          console.log(
            'Chat response:',
            response
          );

          if (response.conversation_id) {
            this.conversationId.set(
              response.conversation_id
            );
          }

          this.addMessage(
            'assistant',
            response.reply ||
              'Thank you. How else can I help?'
          );

          if (
            response.appointment_created &&
            response.appointment_id
          ) {
            this.appointmentId.set(
              response.appointment_id
            );
          }

          this.isSending.set(false);
          this.scrollToBottom();
        },

        error: error => {
          console.error(
            'Chat request error:',
            error
          );

          const backendMessage =
            error?.error?.detail;

          this.errorMessage.set(
            backendMessage ||
              'The AI receptionist is unavailable. Please try again.'
          );

          this.isSending.set(false);
          this.scrollToBottom();
        }
      });
  }

  sendSuggestedMessage(
    message: string
  ): void {
    this.messageInput = message;
    this.sendMessage();
  }

  handleEnter(
    event: Event
  ): void {
    const keyboardEvent =
      event as KeyboardEvent;

    if (keyboardEvent.shiftKey) {
      return;
    }

    keyboardEvent.preventDefault();
    this.sendMessage();
  }

  startNewConversation(): void {
    this.conversationId.set('');
    this.appointmentId.set(null);
    this.errorMessage.set('');
    this.messageInput = '';
    this.messages.set([]);

    this.loadWelcomeMessage();
  }

  formatTime(
    date: Date
  ): string {
    return new Intl.DateTimeFormat(
      'en-GB',
      {
        hour: '2-digit',
        minute: '2-digit'
      }
    ).format(date);
  }

  private addMessage(
    sender: 'customer' | 'assistant',
    message: string
  ): void {
    this.messages.update(
      currentMessages => [
        ...currentMessages,
        {
          id: crypto.randomUUID(),
          sender,
          message,
          createdAt: new Date()
        }
      ]
    );

    this.scrollToBottom();
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      const container =
        this.messagesContainer
          ?.nativeElement;

      if (container) {
        container.scrollTop =
          container.scrollHeight;
      }
    });
  }
}